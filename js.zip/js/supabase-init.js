// js/supabase-init.js
window.supabaseClient = supabase.createClient(
  "https://xdrycmaceeaauioqbdxt.supabase.co",   // YOUR URL
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhkcnljbWFjZWVhYXVpb3FiZHh0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwMjI0MDcsImV4cCI6MjA3ODU5ODQwN30.dF3Wd6n6T9dYwkck1VU0y6mugyv3jyISSLZ7-gxcI_0"            // NOT service role
);

// bucket for resumes + images
window.bucketProfilePics = "profile-pics";
window.bucketResumes = "resumes";
